# พจนานุกรมฉบับซาราซาคสกุล — PWA

โครงสร้างนี้พร้อมนำไปวางบน Vercel / HTTPS static hosting:
- index.html — หน้าเว็บเดิม + PWA hooks
- manifest.webmanifest — ข้อมูลติดตั้ง/ทางลัด
- sw.js — Service Worker สำหรับ app shell/offline shell
- icons/ — ไอคอน 192/512 และ maskable

หมายเหตุสำคัญ: การติดตั้ง PWA ต้องเปิดผ่าน HTTPS หรือ localhost/127.0.0.1; การเปิด index.html โดยตรงด้วย file:// จะไม่ทำให้ Service Worker/PWA install ทำงานตามปกติ

โลโก้เดิมของหน้าเว็บยังคงใช้ URL เดิมในโค้ด และ manifest มี URL โลโก้เดิมเป็นไอคอนเสริม ส่วนไอคอน local ใช้เป็น fallback เพื่อให้ไฟล์ ZIP มี icon ที่ติดตั้งได้จริงในทุกสภาพแวดล้อมที่รองรับ
